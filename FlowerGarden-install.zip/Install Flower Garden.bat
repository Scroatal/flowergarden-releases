@echo off
rem Installs Flower Garden for this Windows user and puts a "Flower Garden" icon on the desktop.
rem After this the game updates itself whenever it starts (if there's internet).
set "DEST=%LOCALAPPDATA%\Flower Garden"
echo Installing Flower Garden...
if not exist "%~dp0FlowerGarden.exe" (
  echo.
  echo Please "Extract All" the zip first, then run this from the extracted folder.
  pause
  exit /b 1
)
if not exist "%DEST%" mkdir "%DEST%"
copy /y "%~dp0FlowerGarden.exe" "%DEST%\" >nul
copy /y "%~dp0FlowerGarden.pck" "%DEST%\" >nul
copy /y "%~dp0FlowerGarden.ico" "%DEST%\" >nul
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-ChildItem -LiteralPath $env:DEST | Unblock-File; $s=(New-Object -ComObject WScript.Shell).CreateShortcut([Environment]::GetFolderPath('Desktop')+'\Flower Garden.lnk'); $s.TargetPath=$env:DEST+'\FlowerGarden.exe'; $s.WorkingDirectory=$env:DEST; $s.IconLocation=$env:DEST+'\FlowerGarden.ico'; $s.Save()"
echo.
echo Done! Double-click "Flower Garden" on the desktop to play.
pause
